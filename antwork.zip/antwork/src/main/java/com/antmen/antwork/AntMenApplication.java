package com.antmen.antwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AntMenApplication {

	public static void main(String[] args) {
		SpringApplication.run(AntMenApplication.class, args);
	}

}
